/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import org.havi.ui.HComponent;

public class mijncomponent extends HComponent {
   

Image sterren;

public int sx = 350;
public int y = 100;
public int ex = 0,ey = 0;
public int er = 1;
    
    public mijncomponent (int x, int y, int b, int h){
        this.setBounds(x,y,b,h);

        sterren   = this.getToolkit().getImage("Background.png");
        
        MediaTracker mt = new MediaTracker(this);

        mt.addImage(sterren,1);
        try {

            mt.waitForAll();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    public void paint(Graphics g){
        g.setColor(Color.GREEN);
       // g.drawLine(, WIDTH, WIDTH, WIDTH)
        g.drawLine(0, 0, 100, 100);
         g.drawLine(0, 100, 100, 0);
         g.drawImage(sterren, 0, 0, this);
      
    }
    
}
