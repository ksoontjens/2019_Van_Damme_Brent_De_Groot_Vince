package hellotvxlet;
import java.awt.Color;
import java.awt.event.ActionEvent;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HStaticText;
import org.havi.ui.HTextButton;
import org.havi.ui.HVisible;
import org.havi.ui.event.HActionListener;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import java.util.Timer;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;

public class HelloTVXlet implements Xlet, HActionListener, UserEventListener {
HScene scene;
mijncomponent c;
int width = 300;
int height = 85;
int nummer = 0;
int vraag = 0;
byte once = 0;
int scoreInt = 0;
int count = 11;
    HStaticText question;
    HStaticText title;
    HStaticText points = new HStaticText("",-10,150,740,100);
    HStaticText ending = new HStaticText("",5000, 5000, width/2, height);
    HStaticText timer = new HStaticText("",200,150,740,100);
    HTextButton[] knop = new HTextButton[7];
    MijnTimeTask mtt=new MijnTimeTask(this);  
    
    public HelloTVXlet() {}
    
    public void update(String vraag, String ant1, String ant2, String ant3, String ant4, int juist)    
    {
     if (once < 1)
     {
             question = new HStaticText("",-10,250,740,100);
             knop[0] = new HTextButton("", 50, 340, width, height);
             knop[1] = new HTextButton("", 370, 340, width, height);
             knop[2] = new HTextButton("", 50, 440, width, height);
             knop[3] = new HTextButton("", 370, 440, width, height);
                 
             for   (int i = 0; i < 4; i++)
             {
                 knop[i].setBackgroundMode(HVisible.BACKGROUND_FILL);
                 knop[i].setBackground(USEDBLACK);
             }
             ending.setVisible(false);
             
      scene.add(timer);
      scene.add(question);
      scene.add(knop[0]);
      scene.add(knop[1]);
      scene.add(knop[2]);
      scene.add(knop[3]); 
           knop[0].setActionCommand("0");
           knop[0].addHActionListener(this);
           knop[1].setActionCommand("1");
           knop[1].addHActionListener(this);
           knop[2].setActionCommand("2");
           knop[2].addHActionListener(this);
           knop[3].setActionCommand("3");
           knop[3].addHActionListener(this);
      once++;
     }
        nummer = juist - 1;
        scene.remove(points);
        String scoreStr = "Score: " + Integer.toString(scoreInt);
        scene.add(points);
        question.setTextContent(vraag, HVisible.NORMAL_STATE);
        points.setTextContent(scoreStr, HVisible.NORMAL_STATE);
        knop[0].setTextContent(ant1, HVisible.NORMAL_STATE);
        knop[1].setTextContent(ant2, HVisible.NORMAL_STATE);
        knop[2].setTextContent(ant3, HVisible.NORMAL_STATE);
        knop[3].setTextContent(ant4, HVisible.NORMAL_STATE);
             
       //up,down,left,right
        knop[0].setFocusTraversal(null, knop[2], null, knop[1]);
         knop[1].setFocusTraversal(null, knop[3], knop[0], null);
          knop[2].setFocusTraversal(knop[0], null, null, knop[3]);
           knop[3].setFocusTraversal(knop[1], null, knop[2], null);  
             
       knop[0].requestFocus();
        scene.repaint();
    }
    
    public void initXlet(XletContext context) 
    {
      scene = HSceneFactory.getInstance().getDefaultHScene();
       
      title = new HStaticText("Welcome to Tsie-Quiz-Bellisimo",-10,0,740,100);
      scene.add(title);
      
             knop[4] = new HTextButton("Start Tsie-Quiz",250, 275, width/4*3, height);    
             knop[4].setBackgroundMode(HVisible.BACKGROUND_FILL);
             knop[4].setBackground(USEDBLACK);
             knop[4].setActionCommand("start");
             knop[4].addHActionListener(this);
        
             scene.add(knop[4]);
             knop[4].requestFocus();
      
      c= new mijncomponent(0,0,720,576); //720,576
      scene.add(c);

      UserEventRepository rep = new UserEventRepository("naam");
      rep.addAllArrowKeys(); //op pijltjes reagern
      EventManager.getInstance().addUserEventListener( this,rep);

     scene.validate();
     scene.setVisible(true);
            Timer t=new Timer();
 
            t.scheduleAtFixedRate(mtt, 0, 1000);
    }

    public void startXlet() {}

    public void pauseXlet() {}

    public void destroyXlet(boolean unconditional) {}
    
    public static final Color USEDGREEN = new Color(51,150,0);
    public static final Color USEDRED = new Color(221,46,46);
    public static final Color USEDBLACK = new Color(58,55,55);
    public static final Color USEDPINK = new Color(255,86,232);
    
    public void actionPerformed(ActionEvent arg0) {
     
        if(arg0.getActionCommand().equals("quit"))
        {
             System.out.println("Quit");
             for (int i = 0; i < 7; i++)
             {
                 knop[i].setVisible(false);
             }
             question.setVisible(false);
             points.setVisible(false);
             ending.setVisible(false);
             timer.setVisible(false);
             title.setVisible(false);
        }
        if(arg0.getActionCommand().equals("retry"))
        {
            System.out.println("Retry");
            nummer = 0;
            vraag = 0;
            once = 0;
            scoreInt = 0;
            vraag++;
            knop[4].setVisible(false);
            update("What year is it currently?","1019","2018","2019","3018",3);
            scene.remove(points);
            scene.remove(ending);
            String scoreStr = "Score: " + Integer.toString(scoreInt);
            scene.add(points);
            points.setTextContent(scoreStr, HVisible.NORMAL_STATE);
            mtt.pause = false;
            for (int i = 0; i < 4; i++)
                    {
                        if (i == nummer)
                        {
                            knop[nummer].setBackground(USEDBLACK);
                        }
                        else
                        {
                            knop[i].setBackground(USEDBLACK);
                        }
                    }
            for(int i = 0; i < 5; i++)
            {
                knop[i].setVisible(true);
            }
                question.setVisible(true);
                points.setVisible(true);
                ending.setVisible(false);
                knop[6].setVisible(false);
                knop[5].setVisible(false);
                knop[4].setVisible(false);
        }
        
        if (arg0.getActionCommand().equals("start"))
        {
            vraag++;
            System.out.println("Start");
            knop[4].setVisible(false);
            update("What year is it currently?","1019","2018","2019","3018",3);
            scene.remove(points);
            String scoreStr = "Score: " + Integer.toString(scoreInt);
            scene.add(points);
            points.setTextContent(scoreStr, HVisible.NORMAL_STATE);
            mtt.pause = false;
        }
        if (arg0.getActionCommand().equals("next"))
        { 
            System.out.println("Next");
            vraag++;
            if(vraag <= 20)
            {
            knop[4].setVisible(false);
                  for (int i = 0; i < 4; i++)
                    {
                        if (i == nummer)
                        {
                            knop[nummer].setBackground(USEDBLACK);
                        }
                        else
                        {
                            knop[i].setBackground(USEDBLACK);
                        }
                    }
            switch (vraag)
            {
                case 1:
                    update("What year is it currently?","1019","2018","2019","3018",3);
                    break;
                case 2:  
                    update("What is the real name of Iron Man","Ben Jones","Rob Stark","Emelia Clarke","Robert Downy Jr.", 4);
                    break;
                case 3:  
                    update("What does the Pikah say","DINGDINGDING","PakiPaki","TakiTaki","Pika-chuuuuuu", 4);
                    break;
                case 4:  
                    update("The answer is really big","ANSWER","An Elephant","Anwser?","This option", 2);
                    break;
                case 5:  
                    update("What is love?","Baby don't hurt me","Baby don't poke me","Baby don't shoke me","Pika-chuuuuuu", 1);
                    break;
                case 6:  
                    update("10+6*3 = ?","48","28","36","19", 2);
                    break; 
                case 7:  
                    update("What is the biggest continent","Europe","Poland","Asia","New York", 3);
                    break;
                case 8:  
                    update("What is the tallest mountain","K2","Makalu","K12","Mount Everest", 4);
                    break;
                case 9:  
                    update("9+6*3 = ?","47","27","36","19", 2);
                    break; 
                case 10:  
                    update("Who plays Khaleesi in Game of Thrones","Emilia Clarke","Jennifer Lawrence","Josh James","Katy Perry", 1);
                    break;
                case 11:  
                    update("What colour is a Welsh poppy","Red","Blue","Green","Yellow", 4);
                    break;
                case 12:  
                    update("When did the Cold War end?","1947","1914","1989","1998", 3);
                    break;
                case 13:  
                    update("What is sushi traditionally wrapped in?","Seaweed","Rice","Fish","Coral", 1);
                    break;
                case 14:  
                    update("Who invented the telephone","Ring","Bell","Ping","Toktok", 2);
                    break;
                case 15:  
                    update("How many states are there in the USA","53","47","50","58", 3);
                    break;
                case 16:  
                    update("Which is the only mammal that can't jump","Seahorse","Horse","Rhino","Elephant", 4);
                    break;
                case 17:  
                    update("What does the roman numeral 'C' represent","10","100","1000","50", 2);
                    break;
                case 18:  
                    update("How many dots are there on 2 dice","21","42","35","98", 2);
                    break;   
                case 19:  
                    update("What is the name of the famous big clock in London","Bug Ben","Big Bertha","Big Ben","Drogonite", 3);
                    break;
                case 20:  
                    update("Which planet is nearest to the sun","Belgium","Pluto","Mercury","Venus", 3);
                    break;

                default:
                    update("Error Testing","A1","B2","C3","D5", 4);
                    break;
            }
            count = 11;
            mtt.pause = false;
            }
            if (vraag > 20)
            {
            for(int i = 0; i < 5; i++)
            {
                knop[i].setVisible(false);
            }
                question.setVisible(false);
                points.setVisible(false);
                ending.setVisible(true);
                ending = new HStaticText("Congratulations!!! You ended with " + scoreInt + " points.", 0, 275, 720, height);
                knop[5] = new HTextButton("Play Again", 100, 150, width/2, height);
                knop[5].setActionCommand("retry");
                knop[5].addHActionListener(this);
                knop[5].setBackgroundMode(HVisible.BACKGROUND_FILL);
                knop[5].setBackground(USEDBLACK);
                scene.add(knop[5]);
                knop[6] = new HTextButton("Quit", 620-(width/2), 150, width/2, height);
                knop[6].setActionCommand("quit");
                knop[6].addHActionListener(this);
                knop[6].setBackgroundMode(HVisible.BACKGROUND_FILL);
                knop[6].setBackground(USEDBLACK);
                scene.add(knop[6]);
                knop[5].setFocusTraversal(null, null, null, knop[6]);
                knop[6].setFocusTraversal(null, null, knop[5], null);
                knop[5].requestFocus();
                scene.add(ending);
                scene.repaint();
            }
        }
        if(arg0.getActionCommand().equals("0")||
                arg0.getActionCommand().equals("1")||
                arg0.getActionCommand().equals("2")||
                arg0.getActionCommand().equals("3"))
        {
            System.out.println("Player anwsered");
            mtt.pause = true;
            timer.setVisible(false);
            
            if (arg0.getActionCommand().equals(Integer.toString(nummer)))
            {
                scoreInt += 1000;
            }
            else
            {
                scoreInt -= 157;
                if (scoreInt < 0)
                {
                    scoreInt = 0;
                }
            }
        for (int i = 0; i < 4; i++)
           {
               if (i == nummer)
               {
                   knop[nummer].setBackground(USEDGREEN);
               }
               else
               {
                   knop[i].setBackground(USEDRED);
               }
            }
        
            scene.remove(points);          
            String scoreStr = "Score: " + Integer.toString(scoreInt);
            scene.add(points);
            points.setTextContent(scoreStr, HVisible.NORMAL_STATE);
        
             knop[4] = new HTextButton("Next",570, 275, width/3, height/2);        
             knop[4].setActionCommand("next");
             knop[4].setBackgroundMode(HVisible.BACKGROUND_FILL);
             knop[4].setBackground(USEDPINK);
             knop[4].addHActionListener(this);
        
             scene.add(knop[4]);
             knop[4].requestFocus();
        }
             scene.add(c);
             scene.repaint();     
    }

    public void userEventReceived(UserEvent e) {
       System.out.println("Event happened");
    }

    public void run() {
        System.out.println("Timer -1");
        count--;
        if (count < 0)
        {
            mtt.pause = true;
            timer.setVisible(false);
            
        for (int i = 0; i < 4; i++)
           {
               if (i == nummer)
               {
                   knop[nummer].setBackground(USEDGREEN);
               }
               else
               {
                   knop[i].setBackground(USEDRED);
               }
            }
            scoreInt -= 1000;
            if(scoreInt < 0)
            {
                scoreInt = 0;
            }
            scene.remove(points);          
            String scoreStr = "Score: " + Integer.toString(scoreInt);
            scene.add(points);
            points.setTextContent(scoreStr, HVisible.NORMAL_STATE);
        
             knop[4] = new HTextButton("Next",570, 275, width/3, height/2);        
             knop[4].setActionCommand("next");
             knop[4].setBackgroundMode(HVisible.BACKGROUND_FILL);
             knop[4].setBackground(USEDPINK);
             knop[4].addHActionListener(this);
        
             scene.add(knop[4]);
             knop[4].requestFocus();
             scene.add(c);
             scene.repaint(); 
        }
        else
        {
        timer.setTextContent("Time Left: " + Integer.toString(count), HVisible.NORMAL_STATE);
        timer.setVisible(true);
        timer.repaint();
        }
    }
}