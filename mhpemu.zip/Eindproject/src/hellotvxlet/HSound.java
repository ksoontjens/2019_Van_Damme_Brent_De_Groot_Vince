/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hellotvxlet;

/**
 *
 * @author vince
 */
public class HSound {

    public HSound() {
    }

    public void load(java.lang.String location) {
    }

    public void load(java.net.URL contents) {
    }

    public void set(byte[] data) {
    }

    public void play() {
    }

    public void stop() {
    }

    public void loop() {
    }

    public void dispose() {
    }
}
