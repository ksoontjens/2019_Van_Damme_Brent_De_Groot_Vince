package hellotvxlet;

import java.util.TimerTask;

public class MijnTimeTask extends TimerTask {

    HelloTVXlet htv;
    boolean pause = true;

    public MijnTimeTask(HelloTVXlet htv) {
        this.htv = htv;
    }

    public void run() {
        if (!pause) {
            htv.run();
        }
    }
}